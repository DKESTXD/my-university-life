// pages/hot/hot.js
import musicList from "../../datas/musicList.js";
Page({
  
  /**
   * 页面的初始数据
   */
  data: {

  },

  navigateToWeb: function() {
    wx.navigateTo({
      url: 'https://www.bilibili.com/video/BV1GJ411x7h7/?share_source=copy_web'
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:function(options) {
    this.setData({
      musics:musicList.musics
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})