// pages/favor/favor.js
import songList from "../../datas/songList.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    singer:"周杰伦",
    dataSource:null,
    dataSourceUp:null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getFavorList();
  },
  getFavorList: function() {
    const db=wx.cloud.database({
      env:'cloud1-3gpruo2f69271d50'
    });
    const musicFavorCollection = db.collection('music_favor');

    musicFavorCollection.get().then(res => {
      if (res.errMsg === 'collection.get:ok') {
        const favorList = res.data.map(item => {
          return [item.sid, item.singer]; 
        });

        this.setData({
          dataSource: favorList,
        });
        console.log('dataSource:', this.data.dataSource);
        console.log(songList);
        this.filterSongs();
        console.log('dataSourceUp:', this.data.dataSourceUp);
      } else {
        console.error('获取数据失败', res.errMsg);
        wx.showToast({
          title: '获取数据失败',
          icon: 'none',
          duration: 2000,
        });
      }
    });
  },

  filterSongs:function(){
    const { dataSource } = this.data;
    const dataSourceUp = [];
    dataSource.forEach(item => {
      let foundSong = null;
      console.log(item);
      switch (item[1]) {
        case "李荣浩":
          foundSong = songList.liRongHao.find(song => song.id === item[0]);
          break;
        case "周杰伦":
          foundSong = songList.zhouJieLun.find(song => song.id === item[0]);
          break;
        case "许嵩":
          foundSong = songList.xuSong.find(song => song.id === item[0]);
          break;
        default:
          console.warn(`未知歌手: ${singer}`);
          break;
      }

      if (foundSong) {
        dataSourceUp.push(foundSong);
      }
    });
    this.setData({
      dataSourceUp:dataSourceUp
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})