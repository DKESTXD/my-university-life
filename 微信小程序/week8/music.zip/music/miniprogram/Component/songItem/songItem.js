// Component/songItem/songItem.js
var app=getApp()
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    item:{
      type:Object,
      value:{}
    },
    singer:{
      type:String,
      value:{}
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    favor:false,
  },

  pageLifetimes:{
    show:function(){
      let states=app.globalData.favorMusics;
      let index=this.properties.item.id;
      this.setData({
        favor:states.music[index],
        counterID:states.counterIDs[index],
      })
    }
  },

  ready:function(){
    console.log(this.properties.item,this.properties.singer);
  },
  /**
   * 组件的方法列表
   */
  methods: {
    favorMusic: function(){
      const db=wx.cloud.database({
        env:'cloud1-3gpruo2f69271d50'
      });
      db.collection('music_favor').add({
        data:{
          sid:this.properties.item.id,
          singer:this.properties.singer,
          favor:true
        },
        success:res=>{
          this.setData({
            counterID:res._id,
            count:1
          })
          wx.showToast({
            title: '已收藏',
          })
          console.log('[数据库][新增记录]成功 记录 _id:',res._id)
          app.globalData.favorMusics.musics[this.properties.item.id]=true
          app.globalData.favorMusics.counterIDs[this.properties.item.id]=this.data.counterID
        },
        fail:err=>{
          wx.showToast({
            icon:'none',
            title: '新增记录失败',
          })
          console.error('[数据库][新增记录]失败:',err)
        }
      })
    },
    disfavorMusic:function(){
      if(this.data.counterID){
        const db=wx.cloud.database({
          env:'cloud1-3gpruo2f69271d50'
        })
        db.collection('music_favor').doc(this.data.counterID).remove({
          success:res=>{
            wx.showToast({
              title: '已取消收藏',
            })
            this.setData({
              counterID:'',
              count:null,
            })
            app.globalData.favorMusics.musics[this.properties.item.id]=true
            app.globalData.favorMusics.counterIDs[this.properties.item.id]=null
          },
          fail:err=>{
            wx.showToast({
              icon:'none',
              title: '删除失败',
            })
            console.error('[数据库][删除记录] 失败：',err)
          }
        })
      }else{
        wx.showToast({
          title: '无counterID，该歌曲还未收藏',
        })
      }
    },

    handleClick:function(){
      var musicPlayer=app.globalData.musicPlayer;
      console.log(musicPlayer);

      app.globalData.playState=1;
      app.globalData.musicPic=this.properties.item.poster;
      app.globalData.musicName=this.properties.item.name;
      app.globalData.musicUrl=this.properties.item.src;
      app.globalData.artistName=this.properties.singer;

      musicPlayer.setData({
        playState:app.globalData.playState,
        musicPic:app.globalData.musicPic,
        musicName:app.globalData.musicName,
        musicUrl:app.globalData.musicUrl,
        artistName:app.globalData.artistName
      })
      musicPlayer.change();
    },
    handleFavor:function(){
      this.setData({
        favor:!this.data.favor
      })
      console.log(this.data.favor)
      if(this.data.favor){
        this.favorMusic();
      }else{
        this.disfavorMusic();
      }
    },
  }
})