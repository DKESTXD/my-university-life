const DEFAULT_MUSIC={
  musicName:"七里香",
  artistName:"周杰伦",
  musicPic:"https://y.gtimg.cn/music/photo_new/T002R300x300M000003DFRzD192KKD.jpg?max%20age-2592000",
  musicUrl:"https://mp3.9ku.com/hot/2004/08-03/58714.mp3",
  playState:0
}

module.exports={
  DEFAULT_MUSIC
}