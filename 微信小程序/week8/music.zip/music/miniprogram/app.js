// app.js
import DEFAULT_MUSIC from './config/index';
App({
  onLaunch() {
    if(!wx.cloud){
      console.error("2.2.3以上的基础库")
    }else{
      wx.cloud.init({
        env:"course-demo",
        traceUser:true,
      })
      this.insertData();
    }
    // 展示本地存储能力
   // const logs = wx.getStorageSync('logs') || []
    //logs.unshift(Date.now())
    //wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    this.globalData.audio.src=DEFAULT_MUSIC.DEFAULT_MUSIC.musicUrl
    this.globalData.audio.play()
    this.getFavorMusics();
    this.insertData();
  },
  insertData:function(){
    const db=wx.cloud.database({
      env:'cloud1-3gpruo2f69271d50'
    });
    const musicCollection=db.collection('allmusic')
    const musicList=require('./datas/songList.js');
    musicCollection.add({
      data: musicList,
      success: function(res) {
        console.log('数据插入成功', res);
      },
      fail: function(err) {
        console.error('数据插入失败', err);
      },
    });
  },
  getFavorMusics:function(){
    console.log("getFavorMusics")
    const db=wx.cloud.database({
      env:'cloud1-3gpruo2f69271d50'
    })
    db.collection('music_favor').field({
      sid:true,
      _id:true,
    }).get({
      success:res=>{
        let musics=new Array(res.data.length+1);
        let counterIDs=new Array(res.data.length+1);
        res.data.forEach(function(item,index){
          musics[item.sid]=true
          counterIDs[item.sid]=item._id
        })
        console.log(musics,counterIDs)
        this.globalData.favorMusics={
          musics:musics,
          counterIDs:counterIDs
        }
        console.log(this.globalData.favorMusics);
      },
      fail:err=>{
        wx.showToast({
          icon:'none',
          title: '查询记录失败',
        })
        console.error('[数据库][查询记录] 失败：',err)
      }
    })
  },

  globalData: {
    userInfo: null,
    audio:wx.createInnerAudioContext(),
    playState:DEFAULT_MUSIC.DEFAULT_MUSIC.playState,
    musicPic:DEFAULT_MUSIC.DEFAULT_MUSIC.musicPic,
    musicName:DEFAULT_MUSIC.DEFAULT_MUSIC.musicName,
    musicUrl:DEFAULT_MUSIC.DEFAULT_MUSIC.musicUrl,
    artistName:DEFAULT_MUSIC.DEFAULT_MUSIC.artistName,
    musicPlayer:null,
    favorMusics:{},
  }
})
