var json = [
    {
        "id" : 1,
        "name": "周杰伦",
        "src": "http://cdnmusic.migu.cn/picture/2019/1031/0254/ASd6c2d9697d2a4f5f96508c8a7ec8b1a8.jpg",
        "songs": [
            { "id": 1, "title": "七里香"},
            { "id": 2, "title": "说好不哭"},
            { "id": 3, "title": "梯田"}
        ]
    },
    {
        "id": 2,
        "name": "李荣浩",
        "src": "http://cdnmusic.migu.cn/picture/2019/1031/0130/AM5251251132424657bd7190cc3690fa40.jpg",
        "songs": [
            { "id": 1, "title": "太坦白"},
            { "id": 2, "title": "不将就"},
            { "id": 3, "title": "老街"}
        ]
    },
    {
        "id" : 3,
        "name": "许嵩",
        "src": "http://cdnmusic.migu.cn/picture/2019/0422/0849/AS1704070955546876.jpg",
        "songs": [
            { "id": 1, "title": "有何不可"},
            { "id": 2, "title": "雅俗共赏"},
            { "id": 3, "title": "素颜"}
        ]
    }
]

module.exports = {
    musics: json
}