var liRongHao = [
	{
		"id": 1,
		"name": "太坦白",
		"src": "https://music.163.com/song/media/outer/url?id=27731177.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000004AhJHV3slLjN.jpg?max_age=2592000"
	},
	{
		"id": 2,
		"name": "不将就",
		"src": "https://music.163.com/song/media/outer/url?id=31654343.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000001fi1zG0EjU2u.jpg?max_age=2592000"
	},
	{
		"id": 3,
		"name": "老街",
		"src": "https://music.163.com/song/media/outer/url?id=133998.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000001LP8hk0a6pOp.jpg?max_age=2592000"
	},
	{
		"id": 4,
		"name": "年少有为",
		"src": "https://music.163.com/song/media/outer/url?id=133998.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000004QnEHc3zjC7J.jpg?max_age=2592000"
	},
	{
		"id": 5,
		"name": "麻雀",
		"src": "https://music.163.com/song/media/outer/url?id=133998.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000003eE8gA3TfuKc.jpg?max_age=2592000"
	},
	{
		"id": 6,
		"name": "模特",
		"src": "https://music.163.com/song/media/outer/url?id=133998.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000004AhJHV3slLjN.jpg?max_age=2592000"
	},
	{
		"id": 7,
		"name": "李白",
		"src": "https://music.163.com/song/media/outer/url?id=133998.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000004AhJHV3slLjN.jpg?max_age=2592000"
	},
	{
		"id": 8,
		"name": "戒烟",
		"src": "https://music.163.com/song/media/outer/url?id=133998.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000003PTZBu0IXqg2.jpg?max_age=2592000"
	}
]

var zhouJieLun = [
  {
    "id": 1,
		"name": "七里香",
		"src": "https://music.163.com/song/media/outer/url?id=167876.mp3",
		"poster": "https://ts4.cn.mm.bing.net/th?id=ODL.848ed8812b82d601874db0259fa138cd&w=298&h=268&c=10&rs=1&qlt=99&bgcl=fffffe&r=0&o=6&dpr=1.4&pid=AlgoBlockDebug"
  },
  {
		"id": 2,
		"name": "说好不哭",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://ts3.cn.mm.bing.net/th?id=OIP.TK5JC7_emBe-kLUAW9VppgHaHZ&w=298&h=298&c=10&rs=1&qlt=99&bgcl=fffffe&r=0&o=6&dpr=1.4&pid=23.1"
	},
	{
		"id": 3,
		"name": "梯田",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://ts4.cn.mm.bing.net/th?id=OIP.dqrgMUgcPL-pEtNd_362iQHaFj&w=298&h=222&c=10&rs=1&qlt=99&bgcl=fffffe&r=0&o=6&dpr=1.4&pid=23.1"
	},
  {
    "id": 4,
		"name": "青花瓷",
		"src": "https://music.163.com/song/media/outer/url?id=167850.mp3",
		"poster": "https://ts4.cn.mm.bing.net/th?id=OIP.QVQRaMgvTE6vLq21MYEINQHaDo&w=298&h=146&c=10&rs=1&qlt=99&bgcl=fffffe&r=0&o=6&dpr=1.4&pid=23.1"
  },
  {
    "id": 5,
		"name": "双截棍",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://ts3.cn.mm.bing.net/th?id=OIP.p28cWUsQ9gmcqmjeP40VeQHaE8&w=298&h=198&c=10&rs=1&qlt=99&bgcl=fffffe&r=0&o=6&dpr=1.4&pid=23.1"
  },
  {
    "id": 6,
    "name": "爷爷泡的茶",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://ts4.cn.mm.bing.net/th?id=ODL.7949d49a9c00c847cf0ea0efdd7d14d5&w=200&h=200&c=9&rs=1&qlt=99&o=6&dpr=1.4&pid=AlgoBlockDebug"
  }
]

var xuSong = [
	{
		"id": 1,
		"name": "有何不可",
		"src": "https://music.163.com/song/media/outer/url?id=167876.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000002KSDg90IaScI.jpg?max_age=2592000"
	},
	{
		"id": 2,
		"name": "庐州月",
		"src": "https://music.163.com/song/media/outer/url?id=167850.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000002CJON012PxwU.jpg?max_age=2592000"
	},
	{
		"id": 3,
		"name": "雅俗共赏",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000000LfSb70Ewn3w.jpg?max_age=2592000"
	},
	{
		"id": 4,
		"name": "断桥残雪",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000001jmC6x1RMfh0.jpg?max_age=2592000"
	},
	{
		"id": 5,
		"name": "多余的解释",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000002KSDg90IaScI.jpg?max_age=2592000"
	},
	{
		"id": 6,
		"name": "城府",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000002KSDg90IaScI.jpg?max_age=2592000"
	},
	{
		"id": 7,
		"name": "玫瑰花的葬礼",
		"src": "https://music.163.com/song/media/outer/url?id=411214279.mp3",
		"poster": "https://y.gtimg.cn/music/photo_new/T002R300x300M000001jmC6x1RMfh0.jpg?max_age=2592000"
	}
]

var songList = [
	{
		"singer": "李荣浩",
		"songs": liRongHao
	},
	{
		"singer": "周杰伦",
		"songs": zhouJieLun
	},
	{
		"singer": "许嵩",
		"songs": xuSong
	}
]

module.exports = {
	liRongHao: liRongHao,
	zhouJieLun: zhouJieLun,
	xuSong: xuSong,
	songList: songList
}
