let myHeading=document.querySelector('h1');
myHeading.textContent='hello world';